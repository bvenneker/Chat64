#ifndef COMMON_H_
#define COMMON_H_

#include "Arduino.h"

#define debug

// Uncomment to enable VICE support
// #define VICE_MODE
// on esp32 my uart is connected like this
// black : pin gnd
// white : pin 17
// green : pin 16
//

#define SwVersion "3.70"


#endif //COMMON_H_
