<?php
// Handle POST request
$branch=1; // the default branch is 1, the stable branch
$regid =0;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["branch"])) $branch = intval($_POST["branch"]);    
    $regid = $_POST["regid"];
}

if ($regid=="4fc1100d45c26412") exit(); // marc
//if ($regid=="96510a705fc27606") exit(); // bart
if ($regid=="aabbccddeeffgghh") exit(); // theo

if ($branch==1) {
echo (file_get_contents('./update/c64version.txt'));
} else {
echo (file_get_contents('./update/c64version_debug.txt'));
}
?>
