<?php
echo (file_get_contents('./update/cpcversion.txt'));
?>

