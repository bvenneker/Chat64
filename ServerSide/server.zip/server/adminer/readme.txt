Adminer - Compact database management
@link https://www.adminer.org/
@author Jakub Vrana, https://www.vrana.cz/
@copyright 2007 Jakub Vrana
@license https://www.apache.org/licenses/LICENSE-2.0 Apache License, Version 2.0
@license https://www.gnu.org/licenses/gpl-2.0.html GNU General Public License, version 2 (one or other)
@version 4.8.1

