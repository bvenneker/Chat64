<!DOCTYPE html>
<?php
// 80.115.27.68 = bart
if (strpos("80.115.27.68",$_SERVER['REMOTE_ADDR'])===false){
  exit;
}
?>
<html lang="en"> 
  <head>
    <title>Chat64</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">    	
    <meta http-equiv="cache-control" content="no-cache, must-revalidate, post-check=0, pre-check=0" />
    <meta http-equiv="cache-control" content="max-age=0" />
    <meta http-equiv="expires" content="0" />
    <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
    <meta http-equiv="pragma" content="no-cache" />


</head>
<body>	
<?php
require_once('../dbCredent.php');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$action="";
$pubstatus="0";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $mu=$_POST["message"];	
  $ri=$_POST["rowid"];	
  if (isset($_POST["save"])) $action="save";
  if (isset($_POST["new"])) $action="new";
  if (isset($_POST["publish"])) $action="publish";
  if (isset($_POST["unpublish"])) $action="unpublish";

}

if ($action=="new"){
  $sql= "INSERT into adminmessages (message,published) VALUES ('".date("Y-m-d") .": this is a message',0)";
  $conn->query($sql);
}

if ($action=="save"){
  $mu = fill40($_POST["mline1"]);
  $mu .= fill40($_POST["mline2"]);
  $mu .= fill40($_POST["mline3"]);
  $mu .= fill40($_POST["mline4"]);
  $mu .= fill40($_POST["mline5"]);
  $mu .= fill40($_POST["mline6"]);
  $mu .= fill40($_POST["mline7"]);
  $mu .= fill40($_POST["mline8"]);
  $mu .= fill40($_POST["mline9"]);
  $mu .= fill40($_POST["mline10"]);
  $mu .= fill40($_POST["mline11"]);
  $mu .= fill40($_POST["mline12"]);
  $mu .= fill40($_POST["mline13"]);
  $mu .= fill40($_POST["mline14"]);
  $mu .= fill40($_POST["mline15"]);
  $mu .= fill40($_POST["mline16"]);
  $mu .= fill40($_POST["mline17"]);
  $mu .= fill40($_POST["mline18"]);

  $mu = trim($mu);
  $sql="update adminmessages set message='$mu' where rowid=$ri";
  $conn->query($sql);
}

$sql= "SELECT * from adminmessages order by rowid desc LIMIT 1";
$result = $conn->query($sql);
$message="";
if ($row = $result->fetch_assoc()) {
    $message = $row['message'];
    $rowid = $row['rowid'];
    $pubstatus = $row['retry'];
    $lines=splitMessageToLines($message);
}

if ($action=="publish"){
  $sql="update adminmessages set published=1 where rowid=$ri";
  $conn->query($sql);
  $pubstatus=1;
}

if ($action=="unpublish"){
  $sql="update adminmessages set published=0 where rowid=$ri";
  $conn->query($sql);
  $pubstatus=0;
}
?>


  
<img src="adminscreenimg.php" width="500px"><br>
<button form="editform" type="submit" name="new" value="new"><img src="./img/new.png" width="30px" title="New Message"></button>
<button form="editform" type="submit" name="save" value="save"><img src="./img/save.png" width="30px" title="Update Message"></button>

<?php
if ($pubstatus==0){
echo '<button form="editform" type="submit" name="publish" value="save"><img src="./img/pub0.png" width="100px" title="Publish the message"></button>';
}
if ($pubstatus==1){
echo '<button form="editform" type="submit" name="unpublish" value="save"><img src="./img/pub1.png" width="100px" title="Unpublish the message"></button>';
}
//echo $rowid;
?>

<form id="editform"  action="" method="post">

<br><br>
<table><tr><td>
<input style="width:500px; height:22px;" name="mline1" value="<?php echo $lines[0];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline2" value="<?php echo $lines[1];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline3" value="<?php echo $lines[2];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline4" value="<?php echo $lines[3];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline5" value="<?php echo $lines[4];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline6" value="<?php echo $lines[5];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline7" value="<?php echo $lines[6];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline8" value="<?php echo $lines[7];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline9" value="<?php echo $lines[8];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline10" value="<?php echo $lines[9];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline11" value="<?php echo $lines[10];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline12" value="<?php echo $lines[11];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline13" value="<?php echo $lines[12];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline14" value="<?php echo $lines[13];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline15" value="<?php echo $lines[14];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline16" value="<?php echo $lines[15];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline17" value="<?php echo $lines[16];?>" type="text"><br>
<input style="width:500px; height:22px;" name="mline18" value="<?php echo $lines[17];?>" type="text"><br>
</td>
<td>&nbsp;&nbsp;&nbsp;</td>
<td><td>Color codes:<br>
[144]=black<br>
[145]=white<br>
[146]=red<br>
[147]=cyan<br>
[148]=purple<br>
[149]=green<br>
[150]=blue<br>
[151]=yellow<br>
[152]=brown<br>
[153]=dark brown<br>
[154]=light red<br>
[155]=dark gray<br>
[156]=mid gray<br>
[157]=light green<br>
[158]=light blue<br>
[159]=light gray<br></td></tr></table>
<br>
<input type="hidden" name="rowid" value="<?php echo $rowid;?>">
</form>

<br>


</body>
</html>
<?php

function splitMessageToLines($message){
  $c=0;
  $count=True;
  $line="";
  foreach (str_split($message) as $ch) {
    if ($ch=='[') $count=False;
    if ($count) $c=$c+1;
    if (!$count and $ch==']') $count=True; 
    $line = $line . $ch;   
    if ($c % 40 == 0 and $c>0) {
      $line = $line ."^^";
      $c=0;
      }
  }
  if ($c%40 != 0) {
      $line = $line ."^^";
      }
  return explode("^^",$line);
}

function fill40($str){
  $c=0;
  $count=True;
  $nstr="";
  foreach (str_split($str) as $ch) {
     if ($ch=='[') $count=False;
     if ($count) $c=$c+1;
     if ($count==False and $ch==']') $count=True; 
     $nstr .= $ch;
     if ($c >= 40) { return $nstr;}
  }
  
  return $nstr . str_repeat(" ",40-$c);
}
