SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP DATABASE IF EXISTS `chat64`;
CREATE DATABASE `chat64` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `chat64`;

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `sendername` varchar(15) DEFAULT NULL,
  `regid` varchar(25) NOT NULL,
  `recipientname` varchar(15) DEFAULT NULL,
  `recipient` varchar(25) DEFAULT NULL,
  `message` varchar(600) NOT NULL,
  `retry` int(11) DEFAULT NULL,
  `seen` int(11) DEFAULT NULL,
  PRIMARY KEY (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `mac` varchar(25) DEFAULT NULL COMMENT 'mac address of the cartridge',
  `regid` varchar(25) DEFAULT NULL COMMENT 'registration id',
  `fullname` varchar(100) DEFAULT NULL,
  `nickname` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `lastseen` bigint(20) DEFAULT 0 COMMENT 'unix timestamp when the user was last active',
  `version` varchar(10) DEFAULT NULL,
  `eeprom` varchar(10) DEFAULT NULL,
  `blocked` tinyint(1) NOT NULL DEFAULT 0,
  `sendmail` int(11) DEFAULT NULL,
  `mandate` int(11) DEFAULT 0,
  PRIMARY KEY (`rowid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

TRUNCATE `users`;
INSERT INTO `users` (`rowid`, `mac`, `regid`, `fullname`, `nickname`, `email`, `lastseen`, `version`, `eeprom`, `blocked`, `sendmail`, `mandate`) VALUES
(0,	'c7d108f070',	'666666cacacacaffff',	'system',	'system',	NULL,	0,	'',	NULL,	1,	0,	0);

