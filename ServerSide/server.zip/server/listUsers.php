<?php
require_once('../dbCredent.php');
//Sven Pook v2


// Set default values
$page = 0;
$pagesize=20;
$call = "";
$listversion = "1";
$regid = "";
$system="Commodore" ;  // Commodore is the default
// Handle POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $regid = test_input($_POST["regid"]);
    if (isset($_POST["page"])) $page = intval($_POST["page"]);
    if (isset($_POST["call"])) $call = test_input($_POST["call"]);
    if (isset($_POST["version"])) $listversion = test_input($_POST["version"]);
    if (isset($_POST["pagesize"])) $pagesize = test_input($_POST["pagesize"]);
	if (isset($_POST["system"])) $system = test_input($_POST["system"]);
} else {
  $system =='CPC';
  $regid='96510a705fc27606';
  $call="list2";
  
}


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$offset = $page * $pagesize;
switch($call){
	case "list":
	  echo get_list_of_users_in_text();
	  break;
	case "list2":
	  echo get_list_of_users_in_text_2($system);
	  break;
	default:
	  echo get_list_of_users_in_petsci($offset, $pagesize);
	  break;
}

//Functions
function get_list_of_users_in_text()
{
    global $conn;
    $list = "";
    $sql = "SELECT LEFT(nickname, 10) AS nickname FROM users WHERE nickname IS NOT NULL AND blocked = 0";
    $result = $conn->query($sql);
    while ($row = $result->fetch_assoc()) {
        $list .= $row['nickname'] . ';';
    }
    return strtolower($list);
}


function get_list_of_users_in_text_2($system)
{
    // get the list of users, first all online users, separated by ;
	// then a fake name as separator "\sep\", including the slashes
	// then a list of off line users, separated by ;
	
    global $conn;
    $list = "";// > UNIX_TIMESTAMP() - 30
    $sql = "SELECT LEFT(nickname, 10) AS nickname FROM users WHERE nickname IS NOT NULL AND blocked = 0 and lastseen >= UNIX_TIMESTAMP() - 30 order by nickname limit 220" ;
    $result = $conn->query($sql);
    // add all on line users to the list
	while ($system=='Commodore' and $row = $result->fetch_assoc()) {
        $list .= chr(149) . $row['nickname'] . ';';  // all online users are green
    }
	while ($system=='Atari' and $row = $result->fetch_assoc()) {
        $list .= $row['nickname'] . ';';  // all online users are inverted (done by the ESP32)
    }
    
	// add a separator
	$list .= "_sep_;";
	$sql = "SELECT LEFT(nickname, 10) AS nickname FROM users WHERE nickname IS NOT NULL AND blocked = 0 and lastseen < UNIX_TIMESTAMP() - 30 order by nickname limit 220" ;
    $result = $conn->query($sql);
	while ($system=='Commodore' and $row = $result->fetch_assoc()) {
        $list .= chr(156) . $row['nickname'] . ';'; // all offline users are gray
    }	   
	while ($system=='Atari' and $row = $result->fetch_assoc()) {
        $list .= $row['nickname'] . ';'; // all offline users not inverted
    }
	//return $list;
    return strtolower($list);
}


function get_list_of_users_in_petsci($offset, $pagesize)
{
    global $conn, $regid,$pagesize;
    $sql = "SELECT LEFT(nickname, 10) AS nickname, lastseen, regid FROM users WHERE nickname IS NOT NULL AND blocked = 0 ORDER BY nickname LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $pagesize, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    $colmwidth=10;
    $screen = "";
    $uc=0;    
    if ($pagesize == 15)$colmwidth=13;    
    
    while ($row = $result->fetch_assoc()) {
        $color = chr(156); // Gray

        if (time() - $row['lastseen'] < 30) $color = chr(149); // Green for online users

        if ($regid == $row['regid']) $color = chr(149); // Green for the current user
            
        $screen .= $color . str_pad($row['nickname'], $colmwidth);
        if(++$uc % 3 == 0) $screen .= " ";
    }
    if ($screen == "") $screen = " ";
    return $screen;
}

function get_list_of_users_for_zxSpectrum($offset, $pagesize ){
	global $conn, $regid,$page;
    $sql = "SELECT LEFT(nickname, 10) AS nickname, lastseen, regid FROM users WHERE nickname IS NOT NULL AND blocked = 0 ORDER BY nickname LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $pagesize, $offset);
    $stmt->execute();
    $result = $stmt->get_result();

    $screen = "";
    $colm= 1;
    $rw= 4;
    
    if ($page %2 == 0){  // true for pages 0,2,4,6,ect
		$rw=4;	
		} else {		
		$rw = 5 + ($pagesize / 2);
	    }
		
    while ($row = $result->fetch_assoc()) {
		
        $colorGray  = chr(16).chr(7).chr(19).chr(130);   // INK,white,BRIGHT,0 (0=130)
        $colorGreen = chr(16).chr(4).chr(19).chr(1);   // INK,green,BRIGHT,1
        $color = $colorGray;
       
        if (time() - $row['lastseen'] < 30) $color = $colorGreen;  // Green for online users
        if ($regid == $row['regid']) $color = $colorGreen;         // Green for the current user
        $screen .= chr(22) . chr($rw) . chr($colm) ;               // AT,row,colm
        $screen .= $color . $row['nickname'];
         
        if ($colm == 1) {
			$colm=16;
			}
		else {
			$colm = 1;			
			$rw = $rw +1;
			}	
    }
    if ($screen == "") $screen = " ";
    return $screen;
    
	}

function test_input($data)
{
    $data = trim($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>


