<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
ini_set("display_startup_errors", 1);

require_once "../dbCredent.php";
$system_regid = "666666cacacacaffff";
$scriptName = "readAllMessages";

// Platform specific settings
$platform = "commodore";
$lineWidth = 40;
$startByteForColor = "[151]";
// end Platform specific settings

$linesFirstPage = 24;
$dateFormatStr = "Y-m-d H:i:s";
$devUsers = "bart,theoc64-nl,tinker,dactari,testsmd,poke_dev,testsmd,bodger";
if ($lineWidth < 40) $dateFormatStr = "M j H:i:s";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $debug=0;
    if (isset($_POST["sendername"])) {
        $sendername = test_input($_POST["sendername"]);
    }
    $macaddress = "";
    if (isset($_POST["mac"])) {
        $macaddress = $_POST["mac"];
    }

    $regid = test_input($_POST["regid"]);
    $lastmessage = test_input($_POST["lastmessage"]);
    $lastprivate = test_input($_POST["lastprivate"]);

    if (isset($_POST["previousPrivate"])) {
        $previousPrivate = test_input($_POST["previousPrivate"]);
    } else {
        $previousPrivate = $lastprivate;
    }

    $type = test_input($_POST["type"]);
    $version = test_input($_POST["version"]);
    $eeprom = test_input($_POST["rom"]);
    if (isset($_POST["lp"])) {
        $lp = test_input($_POST["lp"]);
    }
    if (isset($_POST["t"])) {
        $timeoffset = test_input($_POST["t"]);
    } else {
        $timeoffset = "+1";
    }
    if (strlen($regid) != 16) {
        exit();
    }
} else {
    //exit();
    $macaddress='64bdbd1012';
    $regid='96510a705fc27606';
    $lastmessage=0;
    $lastprivate=0;
    $previousPrivate=71390;
    $type='public';
    $version='3.87';
    $eeprom='3.87';
    $timeoffset = "+1";
    $debug=1;
}

// check if user is registred
$sql = "select * from users where regid='$regid' and mac='$macaddress' and blocked=0";
$result = $conn->query($sql);
if ($row = $result->fetch_assoc()) {
} else {
   if ($macaddress !="") exit();
}

// update versions in the database the database
updateEspVersion($version, $regid);
updateRomVersion($eeprom, $regid);

// update the lastseen field in the database so we know this user is online
$theNickName = strtolower(getNickName($regid));

updateLastSeen($regid);

// Insert a message <Nickname> has joined the chat
if (intval($lastmessage) <= 1) {
    if (!str_contains($devUsers, $theNickName)) {
        insertWelcomeMessage($regid);
    }
}

// Public messages:
if ($type == "public") {
    // get all message id's for a full page
    //$sql = "select sendername,rowid,timestamp, message,regid from messages where sendername <> 'system' and (recipient is null and rowid >" . $lastmessage . ") order by rowid desc limit 35";
    $sql = "select sendername,rowid,timestamp, message,regid from messages where regid <>'' and recipient is null and rowid >" . $lastmessage . " order by rowid desc limit 35";
    if ($result = $conn->query($sql)) {
        $totlines = 0;
        $targetID = 0;
        $ids = [];
        while (($row = $result->fetch_assoc()) and $totlines < $linesFirstPage ) {
            // add one line for the header
            if ($row["sendername"] != "system") $totlines++;           
            // get the message length and replace the higher bytes (that contain color information)
            list($message, $len) = replace_higher_bytes($row["message"]);
            // calculate the number of lines.
            $len = ceil($len / $lineWidth);
            if ($row["sendername"] != "system") $totlines += $len;
            $targetID = $row["rowid"];
            $ids[]= $row["rowid"];
        }
        
        if (count($ids)!=0) {            
            $ic = 1;
            echo "[";            
            foreach (array_reverse($ids) as $i) {
                outputMessage($i);
                if (count($ids) > $ic++) echo ",";
            }
            echo "]";
        } else {
        
            $pm = countPrivateMessages($regid, $previousPrivate);
            echo '{"rowid":"' . $lastmessage . '","timestamp":"0","message":"0","nickname":"0","len":0,"pm":' . $pm ."}";
        }
    }

    $conn->close();
    flush();
    exit(0);
}

// =================================================================================================================
// the same for private messages
if ($type == "private") {
    // get all messages at once
    $sql = "select sendername, rowid,timestamp, message,regid,recipientname from messages where ((regid='" . $regid . "' or recipient ='" . $regid . "')  and rowid >" . $lastprivate . " and recipient is not null) order by rowid desc limit 25";
    if ($result = $conn->query($sql)) {
        $totlines = 0;
        $ids = [];
        while (($row = $result->fetch_assoc()) and $totlines < $linesFirstPage ) {
            // add one line for the header
            $totlines++; 
            // get the message length and replace the higher bytes (that contain color information)
            list($message, $len) = replace_higher_bytes($row["message"]);
            // calculate the number of lines.
            $len = ceil($len / $lineWidth);
            $totlines += $len;
            $ids[]= $row["rowid"];
        }
        if (count($ids)!=0) {
            echo "[";
            $ic = 1;
            foreach (array_reverse($ids) as $i) {
                outputMessage($i);
                if (count($ids) > $ic++) echo ",";
            }
            echo "]";
        } else {
            $pm = countPrivateMessages($regid, $previousPrivate);
            echo '{"rowid":"' . $lastprivate . '","timestamp":"0","message":"0","nickname":"0","len":0,"pm":' . $pm . "}";
        }
    }
    $conn->close();
    flush();
    exit(0);
}

// =================================================================================================================
function getNickName($regid)
{
    global $conn;
    global $system_regid;
    $sql = "select nickname from users where regid='" . $regid . "'";
    $result = $conn->query($sql);
    $nickname = "";
    if ($row = $result->fetch_assoc()) {
        $nickname = $row["nickname"];
        if (strlen($nickname) <= 1) {
            $nickname = "a user";
        }
    }
    return $nickname;
}
// =================================================================================================================
function insertWelcomeMessage($regid)
{
    global $conn, $macaddress;
    global $system_regid;
    $sql = "select nickname from users where regid='" . $regid . "'";
    $result = $conn->query($sql);
    $nickname = "";
    if ($row = $result->fetch_assoc()) {
        $nickname = $row["nickname"];
        if (strlen($nickname) <= 1) {
            $nickname = "a user";
        }
    }
    // prevent flooding the chat with this message (can happen when fetching the first page of messages fails for some reason
    $cSql = "select * from messages where message like '%" . $nickname . " joined%' and TIMESTAMPDIFF(SECOND, timestamp, NOW()) < 300";
    $result = $conn->query($cSql);
    $fc = $result->num_rows;
    if ($fc != 0) return;

    $tmessage = "[143][146]system: " . str_pad($nickname . " joined the chat", 32, " ", STR_PAD_LEFT);

    // delete old welcome messages.
    $sql = "delete from messages where message='" . $tmessage . "'";
    $conn->query($sql);

    // post a new message "<myname> has joined the chat"
    $sql ="INSERT INTO messages (sendername, regid, message) VALUES ('system','" . $system_regid . "','" . $tmessage . "')";
    $conn->query($sql);
    
}
// =================================================================================================================
function updateEspVersion($version, $regid)
{
    global $conn;
    // update the ESP32 version
    if (strlen($version) > 0) {
        $sql = "update users set version='" . $version . "' where regid='" . $regid . "'";
        $conn->query($sql);
    }
}

// =================================================================================================================
function updateRomVersion($eeprom, $regid)
{
    global $conn;
    // Update the eeprom version
    if (strlen($eeprom) > 0) {
        $sql = "update users set eeprom='" . $eeprom . "' where regid='" . $regid . "'";
        $conn->query($sql);
    }
}
// =================================================================================================================
function updateLastSeen($regid)
{
    global $conn;
    // update the last seen field in the users table so we can know this user is online
    $sql = "update users set lastseen=" . time() . "  where regid='" . $regid . "'";
    $conn->query($sql);
}

// =================================================================================================================
function countPrivateMessages($regid, $lp)
{
    global $conn;
    $sql = "select * from messages where recipient ='" . $regid . "'  and rowid >" . $lp;
    $result = $conn->query($sql);
    $pm = $result->num_rows;
    return $pm;
}
// =================================================================================================================

function replace_higher_bytes($str)
{
    global $platform;
    // this function replaces the [145] for byte value 145 en returns also the length of the message excluding those bytes.
    $pattern = "/\[\d\d\d\]/";

    if ($platform == "commodore") {
        preg_match_all($pattern, $str, $out);
        $c = 0;
        foreach ($out[0] as $o) {
            $v = intval(substr($o, 1, -1));
            $str = str_replace($o, chr($v), $str);
            $c++;
        }
        return [$str, strlen($str) - $c]; // return for commodore
    }

    if ($platform == "atari") {
        preg_match_all($pattern, $str, $out);
        foreach ($out[0] as $o) {
            $v = intval(substr($o, 1, -1));
            $str = str_replace($o, "", $str); // for Atari we want to remove these bytes
        }
        $str = str_replace(str_repeat(" ", 40), "", $str);
        return [$str, strlen($str)]; // return for atari
    }

    if ($platform == "spectrum") {
        preg_match_all($pattern, $str, $out);
        $c = 0;
        foreach ($out[0] as $o) {
            $v = intval(substr($o, 1, -1));
            $str = str_replace($o, chr($v), $str);
            $c++;
        }
        return [$str, strlen($str) - $c]; // return for spectrum
    }

    if ($platform == "msx") {
        preg_match_all($pattern, $str, $out);
        foreach ($out[0] as $o) {
            $v = intval(substr($o, 1, -1));
            $str = str_replace($o, "", $str); // for MSX we want to remove these bytes
        }
        return [$str, strlen($str)];
    }
}

// =================================================================================================================
function test_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
// =================================================================================================================
function trimMessage($message)
{
    $message = trim($message);

    // sometimes, for some reason, there are extra bytes at the end of the message.
    // They are formatted like this [nnn]. We need to delete those.

    while (preg_match("/^\[\d\d\d\]$/", substr($message, -5))) {
        $message = substr($message, 0, -5);
        $message = trim($message);
    }
    return $message;
}
// =================================================================================================================
function trim_40_to_32($message, $len)
{
    // some computers have a screen width of 32 chars,
    // the c64 has a screen width of 40 chars.
    // Messages in the database are always with line length 40, even if they come from computers with smaller screens
    // So the C64 displays it correctly.
    // But for smaller computers we need to reduce the line length (if possible) from 40 to 32.
    // So if a line ends with 8 space characters, we trim those

    // we need to find out if characters 33 to 40 are spaces, but there may be extra bytes in there for color information
    $L1 = 0;
    $newMessage = "";
    $chars = str_split($message);
    foreach ($chars as $char) {
        if (ord($char) < 128) {
            $L1++;
        }
        $newMessage = $newMessage . $char;

        if (($L1 == 40) | ($L1 == 80) | ($L1 == 120)) {
            if (str_ends_with($newMessage, "        ")) {
                //echo ($newMessage."|");

                $newMessage = substr_replace($newMessage, "", -8, 8);
                //echo ($newMessage."|");
            }
        }
    }
    $newMessage = trim($newMessage);

    while (ord(substr($newMessage, -1)) > 127) {
        $newMessage = substr_replace($newMessage, "", -1);
        $newMessage = trim($newMessage);
    }

    // the message : 'system: bart joined the chat' is a bit too long for screens of 32 width,
    // It should fit on one line so lets remove some spaces and change one word.
    if (
        str_contains($newMessage, "system:") and
        str_contains($newMessage, "joined")
    ) {
        $newMessage = str_replace("system:       ", "system:", $newMessage);
        $newMessage = str_replace("system:      ", "system:", $newMessage);
        $newMessage = str_replace("joined", "joins", $newMessage);
    }

    // count the new length
    $L1 = 0;
    $chars = str_split($newMessage);
    foreach ($chars as $char) {
        if (ord($char) < 128) {
            $L1++;
        }
    }
    return [$newMessage, $L1];
}
// =================================================================================================================
function cutAtName($message)
{
    // save the color byte for later
    if (substr($message, 0, 1) === "[") {
        $colorBytes = substr($message, 0, 5);
    }

    $backupMessage = $message;
    // find the first space or colon or semicolon
    $p = 0;
    while (1) {
        if (
            substr($message, 0, 1) === " " or
            substr($message, 0, 1) === ":" or
            substr($message, 0, 1) === ";"
        ) {
            break;
        }
        $message = substr($message, 1);
        # prevent never ending loop (It does seem to happen some how)
        if ($p++ > 20) {
            #something is wrong here. restore the message
            $message = $backupMessage;
            break;
        }
    }

    $message = $colorBytes . substr($message, 1);
    return $message;
}

// =================================================================================================================
function outputMessage($rowid)
{
    global $conn;
    global $lastprivate;
    global $regid;
    global $system_regid;
    global $timeoffset;
    global $previousPrivate;
    global $lineWidth;
    global $dateFormatStr;
    global $platform;
    global $startByteForColor;
    global $debug;
    $private = true;
    $sql = "select * from messages where rowid='" . $rowid . "'";
    $result = $conn->query($sql);
    // if ($debug==1) echo ">>".$rowid ."<<";
    if ($row = $result->fetch_assoc()) {
        $messageLine = trim($row["message"]);
        $messageLine = ltrim($messageLine);
        $messageLine = str_replace(str_repeat(" ", 40), "", $messageLine);
        $localtime = $row["timestamp"];

        // Get the offset of this server from UTC
        date_default_timezone_set("GMT"); // this is UTC timezone
        $dateTimeGMT = date("Y-m-d H:i:s");

        date_default_timezone_set("CET"); // this is the locals servers timezone
        $dateTimeLocal = date("Y-m-d H:i:s");

        $date1 = strtotime($dateTimeGMT);
        $date2 = strtotime($dateTimeLocal);
        $diff = $date2 - $date1; // diff is the offset in seconds

        date_default_timezone_set("CET"); // restore our timezone

        // calculate UTC time from the value in the database
        $timeoffset = str_replace(",", ".", $timeoffset);
        $timeoffset = floatval($timeoffset);
        $localtime = strtotime($row["timestamp"]) - $diff + $timeoffset * 3600;
        $localtime = date($dateFormatStr, $localtime);
        $channel = "private";
        // system message
        if ($row["regid"] == $system_regid) {
            // this is a system message
            // calculate the age of the message
            $rowTime = strtotime($row["timestamp"]);
            if ($rowTime < time() - 600) {
                return;
            }
            $channel = "public";
            $message = trimMessage($messageLine);
            if ($platform == "atari") {
                // this is an extra step for atari
                list($message, $len) = replace_higher_bytes($message); // again?
                $message = invertText($message);
            }
        } elseif (
            $row["recipient"] == $regid or
            $row["regid"] == $regid and is_null($row["recipient"]) == false
        ) {
            // private message
            $channel = "private";
            $messageLine = cutAtName($messageLine);

            # remove point or comma from sendername
            $senderName = $row["sendername"];
            $senderName = str_replace(".", "", $senderName);
            $senderName = str_replace(",", "", $senderName);
            $senderName = str_replace("{", "", $senderName);
            $senderName = str_replace("}", "", $senderName);
            

            # remove point or comma from recipientname
            $recipName = $row["recipientname"];
            $recipName = str_replace(",", "", $recipName);
            $recipName = str_replace(".", "", $recipName);
            $recipName = str_replace("{", "", $recipName);
            $recipName = str_replace("}", "", $recipName);

            $senderRegId = $row["regid"];
            if (str_contains($messageLine, "^c^")) {
                // Skip the header so the messages are stitched together
                $message = trimMessage($messageLine);
                $message = str_replace("^c^", "", $message);
            } else {
                // create the header text for a private message:
                if ($platform == "commodore") {
                    $message = $startByteForColor . $localtime . " " . $senderName . " @" . $recipName . ":";
                    if ( strlen($message) > 40) {
                       $localtime = strtotime($row["timestamp"]) - $diff + $timeoffset * 3600;
                       $dateFormatStr = "Y-m-d H:i";
                       $localtime = date($dateFormatStr, $localtime);
                       $message = $startByteForColor . $localtime . " " . $senderName . " @" . $recipName . ":";
                    }
                    $message = str_pad($message, 45) . $messageLine;
                    $message = trimMessage($message);
                }
                if ($platform == "atari") {
                    $message =
                        $startByteForColor .
                        $localtime .
                        " " .
                        $senderName .
                        " @" .
                        $recipName .
                        ":";
                    if ( strlen($message) > 40) {
                       $localtime = strtotime($row["timestamp"]) - $diff + $timeoffset * 3600;
                       $dateFormatStr = "Y-m-d H:i";
                       $localtime = date($dateFormatStr, $localtime);
                       $message = $startByteForColor . $localtime . " " . $senderName . " @" . $recipName . ":";
                    }
                    $message = invertText(str_pad($message, 40)) . $messageLine;
                    $message = trimMessage($message);
                }
                if ($platform == "spectrum") {
                    // On the ZX Spectrum the line length is to short so we need to cut some data
                    if (
                        strtolower($senderName) ==
                        strtolower(getNickName($regid))
                    ) {
                        $message = "[151]" . $localtime . " @" . $recipName; // the message is FROM you
                    } else {
                        $message =
                            "[151]" . $localtime . " from " . $senderName; // the message if TO you
                    }
                    $message = str_pad($message, 45) . $messageLine;
                    $message = trimMessage($message);
                }
                if ($platform == "msx") {
                    // create the header text for a private message:
                    $message =
                        substr($localtime, 0, -3) .
                        " " .
                        $senderName .
                        " @" .
                        $recipName .
                        ":";
                    $message = substr($message, 0, 32);
                    $message =
                        yellowTextMSX(str_pad($message, 32)) . $messageLine;
                    $message = trimMessage($message);
                }
            }
        } else {
            // public message
            $channel = "public";
            // create the header text for a public message:

            if ($platform == "commodore") {
                $message =
                    $startByteForColor .
                    $localtime .
                    " " .
                    $row["sendername"] .
                    ":";
                $message = str_pad($message, 45) . $messageLine;
                $message = trimMessage($message);
            }
            if ($platform == "atari") {
                $message =
                    $startByteForColor .
                    $localtime .
                    " " .
                    $row["sendername"] .
                    ":";
                $message = invertText(str_pad($message, 40)) . $messageLine;
                $message = trimMessage($message);
            }
            if ($platform == "spectrum") {
                $message = str_pad($message, 45) . $messageLine;
                $message = trimMessage($message);
            }
            if ($platform == "msx") {
                $message = $localtime . " " . $row["sendername"] . ":";
                $message = yellowTextMSX(str_pad($message, 32)) . $messageLine;
                $message = trimMessage($message);
            }
        }

        // get the message length and replace the higher bytes (that contain color information)
        // $message = ascii2Atari($message);
        list($message, $len) = replace_higher_bytes($message);
        if ($lineWidth == 32) {
            list($message, $len) = trim_40_to_32($message, $len); // reduce line length to 32 (if possible), and return the new length
        } 

        if ($platform == "msx") {
            $msxSysMsg = false;
            list($message, $msxSysMsg) = redSysMessage($message);
        }

        // calculate the number of lines.
        $len = ceil($len / $lineWidth);
        if ($platform == "msx" and $msxSysMsg == false) {
            $len++;
        }
    }

    // build the json encoded string for output
    $message = base64_encode($message);

    // count the number of available private messages. We can not use $lastprivate for this because that will be zero at the start of every session
    // $previousPrivate is stored in eeprom so that contains the last private message id, even from the previous session.

    $pm = countPrivateMessages($regid, $previousPrivate);

    $out = [
        "rowid" => $row["rowid"],
        "timestamp" => $localtime,
        "message" => $message,
        "regid" => $regid,
        "nickname" => $row["sendername"],
        "lines" => $len,
        "pm" => $pm,
        "channel" => $channel,
    ];

    // output the row
    if (count($out) > 0) {
        echo json_encode($out);
    }
}

// =================================================================================================================
function redSysMessage($message)
{
    // system message should be red (for MSX).
    $sysmsg = false;
    if (str_contains($message, "system:") and str_contains($message, "joins")) {
        $sysmsg = true;
        $message = strtolower($message);
        $message = str_pad($message, 32, " ", STR_PAD_RIGHT);

        $message = strtr($message,[
            chr(32)=>chr(242),
            chr(95)=>chr(243),
            chr(33)=>chr(244),
            chr(46)=>chr(245),
            chr(44)=>chr(246),
            chr(58)=>chr(247)
            ]);
            
        $mystr = "";        
        foreach (str_split($message) as $ch) {
            $c = ord($ch);
            if ($c >= 97 and $c <= 122) $c = $c + 119;            
            $mystr .= chr($c);
        }
        $message = $mystr;
    }
    return [$message, $sysmsg];
}

// =================================================================================================================
function invertText($str)
{
    // This is only for Atari
    $nt = "";
    foreach (str_split($str) as $char) {
        $nt .= chr(128 + ord($char));
    }
    return $nt;
}

// =================================================================================================================
function yellowTextMSX($str)
{
    // This is only for MSX
    $nt = "";
    $str = str_replace("_", chr(92), $str);
    foreach (str_split($str) as $char) {
        if (ord($char) > 31 and ord($char) < 95) {
            $nt .= chr(96 + ord($char));
        } // 1,2,3 .. A..Z, @,
        if (ord($char) > 96 and ord($char) < 123) {
            $nt .= chr(93 + ord($char));
        } // small a..z
    }
    return $nt;
}

// =================================================================================================================
function ascii2Atari($str)
{
    $nt = "";
    foreach (str_split($str) as $char) {
        if (ord($char) >= 97) {
            $nt .= $char;
        } else {
            $nt .= chr(ord($char) - 32);
        }
    }
    return $nt;
}

?>
