<?php
// install.php

function showForm($error = "") {
    ?>
    <html>
    <head><title>Database Installer</title></head>
    <body>
        <h2>Database Installer</h2>
        <?php if ($error): ?>
            <p style="color:red;"><strong>Error:</strong> <?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <form method="post">
            <h3>MySQL admin Credentials</h3>
            <p>
                We need MySQL access to create a new database and user.<br>
                Please enter your admin credentials below.
            </p>
            <label>Admin Username: <input type="text" name="rootuser"></label><br>
            <label>Admin Password: <input type="password" name="rootpass"></label><br><br>

            <h3>New Database Setup</h3>
            <label>Database Name: <input type="text" name="dbname" value="chat64"></label><br>
            <label>New Username: <input type="text" name="dbuser" value="chat64dbuser"></label><br>
            <label>New User Password: <input type="password" name="dbpass"></label><br><br>

            <input type="submit" value="Install">
        </form>
    </body>
    </html>
    <?php
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $rootuser = $_POST["rootuser"] ?? "";
    $rootpass = $_POST["rootpass"] ?? "";
    $dbname   = $_POST["dbname"] ?? "";
    $dbuser   = $_POST["dbuser"] ?? "";
    $dbpass   = $_POST["dbpass"] ?? "";

    try {
        // Connect as root
        $pdo = new PDO("mysql:host=localhost", $rootuser, $rootpass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Create DB
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

        // Create user & grant privileges
        $pdo->exec("CREATE USER IF NOT EXISTS '$dbuser'@'localhost' IDENTIFIED BY '$dbpass'");
        $pdo->exec("GRANT ALL PRIVILEGES ON `$dbname`.* TO '$dbuser'@'localhost'");
        $pdo->exec("FLUSH PRIVILEGES");

        // Import schema
        $pdo->exec("USE `$dbname`");
        $schema = file_get_contents("dbschema.sql");
        $pdo->exec($schema);

        echo "<h3>Installation complete ✅</h3>";

        // Create credentials file with mysqli connection
        $credFile = realpath(__DIR__ . '/../').'dbCredent.php';
        $credContent = "<?php\n".
                       "\$hostname = '127.0.0.1';\n".
                       "\$dbname   = '$dbname';\n".
                       "\$username = '$dbuser';\n".
                       "\$password = '$dbpass';\n".
                       "\$conn = new mysqli(\$hostname, \$username, \$password, \$dbname);\n".
                       "?>\n";

        if (@file_put_contents($credFile, $credContent) === false) {
            echo "<p>Database created, but I could not create $credFile.</p>";
            echo "<p>Please create the file manually with the following content:</p>";
            echo "<pre>".htmlspecialchars($credContent)."</pre>";
        } else {
            echo "<p>Credentials file <code>$credFile</code> created.</p>";
        }

        

        // Try deleting this installer
        $installer = __FILE__;
        if (!@unlink($installer)) {
            echo "<p><strong>Security notice:</strong> Could not delete <code>install.php</code> automatically.</p>";
            echo "<p>Please delete this file manually after installation:</p>";
            echo "<pre>rm ".basename($installer)."</pre>";
        } else {
            echo "<p>Installer file <code>".basename($installer)."</code> has been removed automatically for safety.</p>";
        }

    } catch (Exception $e) {
        showForm($e->getMessage());
    }
} else {
    showForm();
}
?>
