<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$scriptName="readAllMessages";

require_once('../dbCredent.php');
$system_regid="666666cacacacaffff";

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (isset($_POST["sendername"])) $sendername = test_input($_POST["sendername"]);
  $macaddress="";
  if (isset($_POST["mac"])) $macaddress=$_POST["mac"];
  
  $regid = test_input($_POST["regid"]);
  $lastmessage = test_input($_POST["lastmessage"]);
  $lastprivate = test_input($_POST["lastprivate"]);

  if (isset($_POST["previousPrivate"])) 
	$previousPrivate = test_input($_POST["previousPrivate"]);
  else 
    $previousPrivate = $lastprivate;
  
  $type = test_input($_POST["type"]);
  $version = test_input($_POST["version"]);
  $eeprom =  test_input($_POST["rom"]);
  if (isset($_POST["lp"])) $lp =  test_input($_POST["lp"]);  
  if (isset($_POST["t"])) $timeoffset =  test_input($_POST["t"]);
  else $timeoffset = "+1";
  if (strlen($regid) != 16) exit();
  
} else  {	
//	exit();
	$regid='a1b90ace21591a67';
	$lastmessage=3763;
	$lastprivate=0;
	$type='public';
	$version='3.63';
	$eeprom='3.59';
	$timeoffset="+2";
	$previousPrivate='3087';
//	

}

// check if user is registred 
$sql="select * from users where regid='$regid' and blocked=0";
$result = $conn->query($sql);
if ($row = $result->fetch_assoc()) {
	
} else {
//exit();
}

// update versions in the database the database
updateEspVersion($version,$regid);
updateRomVersion($eeprom,$regid);

// update the lastseen field in the database so we know this user is online
updateLastSeen($regid);

// Insert a message <Nickname> has joined the chat
if (intval($lastmessage) <= 1) {
	$theNickName = strtolower(getNickName($regid));	
	if (!str_contains('dactari,testsmd,testtht,testzx,textxl,testxl',$theNickName)) insertWelcomeMessage($regid);
}
	
// Public messages: 
if ($type=='public') {

	// get all messages at once
        $sql = "select sendername,rowid,timestamp, message,regid from messages where (recipient is null and rowid >" . $lastmessage . ") order by rowid desc limit 25";	
	if ($result = $conn->query($sql)){	
		$totlines=0;
		$targetID=0;
		$ids="";
                $theSender = getNickName($regid);
		while($row = $result->fetch_assoc() and $totlines < 21){
			// create the header:
			$message=invertText($row["timestamp"] . " " . $row["sendername"] .":");
			$message=str_pad($message,40," "). str_replace(str_repeat(' ', 40),'',$row["message"]);
			// get the message length and replace the higher bytes (that contain color information)
			list($message,$len)=replace_higher_bytes($message);
			// calculate the number of lines.
			$len = ceil($len/40); 
			$totlines += $len;

			$targetID = $row["rowid"];
			$ids = $row["rowid"] . '^^' . $ids;

		}
		
		if ($ids != "") {
			$ids = substr($ids, 0, -2);
			 echo"[";
			 $ic=1;
			 foreach (explode("^^",$ids) as $i) {
			   outputMessage($i);
			   if (count(explode("^^",$ids)) > $ic++) echo ",";
				 }
			 echo"]";
		} else {
			$pm=countPrivateMessages($regid,$previousPrivate);
			echo '{"rowid":"'.$lastmessage.'","timestamp":"0","message":"0","nickname":"0","len":0,"pm":'.$pm.'}';
			}

	}
	

	$conn->close();
	flush();
	exit(0);
}

// =================================================================================================================
// the same for private messages 
if ($type=='private'){
        
		// get all messages at once
                $sql = "select sendername, rowid,timestamp, message,regid,recipientname from messages where ((regid='".$regid."' or recipient ='".$regid."')  and rowid >" . $lastprivate . "  and recipient is not null) order by rowid desc limit 25";
		if ($result = $conn->query($sql)){
		$totlines=0;
		$targetID=0;
		$ids="";
		while($row = $result->fetch_assoc() and $totlines < 21){
			// create the header:
			$message=invertText($row["timestamp"] . " " . $row["sendername"] .":");
                        $message=str_pad($message,40," "). str_replace(str_repeat(' ', 40),'',$row["message"]);
			// get the message length and replace the higher bytes (that contain color information)
			list($message,$len)=replace_higher_bytes($message);
			// calculate the number of lines.
			$len = ceil($len/40); 
			$totlines += $len;

			$targetID = $row["rowid"];
			$ids = $row["rowid"] . '^^' . $ids;

		}
		if ($ids!=""){
			$ids = substr($ids, 0, -2);
			 echo"[";
			 $ic=1;
			 foreach (explode("^^",$ids) as $i) {
			   outputMessage($i);
			   if (count(explode("^^",$ids)) > $ic++) echo ",";
				 }
			 echo"]";
		 } else {
			$pm=countPrivateMessages($regid,$previousPrivate);
			echo '{"rowid":"'.$lastprivate.'","timestamp":"0","message":"0","nickname":"0","len":0,"pm":'.$pm.'}';
			}

		}
		$conn->close();
		flush();
		exit(0);
}

// =================================================================================================================
// =================================================================================================================
function getNickName($regid){
	global $conn;	
	global $system_regid;
	$sql="select nickname from users where regid='".$regid."'";
	$result = $conn->query($sql);
	$nickname="";
	if ($row = $result->fetch_assoc()) {
		$nickname=$row["nickname"];
		if (strlen($nickname) <=1) $nickname="a user";
	}
	return $nickname;
	}
// =================================================================================================================
function insertWelcomeMessage($regid) {
	global $conn,$macaddress;	
	global $system_regid;
	$sql="select nickname from users where regid='".$regid."'";
	$result = $conn->query($sql);
	$nickname="";
	if ($row = $result->fetch_assoc()) {
		$nickname=$row["nickname"];
		if (strlen($nickname) <=1) $nickname="a user";
	}
	// prevent flooding the chat with this message (can happen when fetching the first page of messages fails for some reason
    $cSql="select * from messages where message like '%".$nickname." joined%' and TIMESTAMPDIFF(SECOND, timestamp, NOW()) < 300";
    $result = $conn->query($cSql);
    $fc = $result->num_rows ;
    if ($fc!=0) return;
    
	$tmessage="[143][146]system: ".str_pad($nickname." joined the chat", 32, " ", STR_PAD_LEFT);

	// delete old messages that say I joined the chat.
	$sql="delete from messages where message='".$tmessage."'"  ;
	$conn->query($sql);

	// post a new message "<myname> has joined the chat"			
	$sql = "INSERT INTO messages (sendername, regid, message) VALUES ('system','" . $system_regid . "','" . $tmessage ."')";
	
	// only insert the message when the nickname is filled in
	if (strlen($nickname) > 1) $conn->query($sql);
}
// =================================================================================================================
function updateEspVersion($version,$regid){
	global $conn;
	// update the ESP32 version
	if (strlen($version) > 0) {
		$sql="update users set version='".$version."' where regid='".$regid."'";
		$conn->query($sql);
	}
}

// =================================================================================================================
function updateRomVersion($eeprom,$regid){
	global $conn;
	// Update the eeprom version
	if (strlen($eeprom) > 0) {
		$sql="update users set eeprom='".$eeprom."' where regid='".$regid."'";
		$conn->query($sql);
	}
}
// =================================================================================================================
function updateLastSeen($regid){
	global $conn;
	// update the last seen field in the users table so we can know this user is online
	$sql="update users set lastseen=".time()."  where regid='".$regid."'";
	$conn->query($sql);

}
// =================================================================================================================
function countPublicMessages($regid,$lastmessage) {
	global $conn;
	$sql="select * from messages where regid<>'".$system_regid."' and recipient is null and rowid >" . $lastmessage ;
	$result = $conn->query($sql);
    $pm = $result->num_rows ;
	return $pm;
}
// =================================================================================================================
function countPrivateMessages($regid,$lp) {
	global $conn;
	$sql = "select * from messages where recipient ='" . $regid  . "'  and rowid >" . $lp ;
    $result = $conn->query($sql);
    $pm = $result->num_rows ;
	return $pm;
}
// =================================================================================================================

function replace_higher_bytes($str){
  // this function replaces the [145] for byte value 145 en returns also the length of the message excluding those bytes.
  $pattern = "/\[\d\d\d\]/";
  preg_match_all($pattern, $str,$out);
      
    foreach ($out[0] as $o) {
      $v=intval(substr($o,1,-1));
      // $str = str_replace($o,chr($v),$str);
      $str = str_replace($o,'',$str); // for Atari we want to remove these bytes
      
    }
  $str = str_replace(str_repeat(" ",40),"",$str) ;
  return array($str,strlen($str));
}
// =================================================================================================================
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
// =================================================================================================================
function trimMessage($message){
  $message=trim($message);

  // sometimes, for some reason, there are extra bytes at the end of the message.
  // They are formatted like this [nnn]. We need to delete those.
  
  while (preg_match("/^\[\d\d\d\]$/",substr($message,-5))) {
      $message=substr($message,0,-5);
      $message=trim($message);      
  }
  return $message;
}
// =================================================================================================================
function cutAtName($message){
  // save the color byte for later
  if (substr($message,0,1)==="[" )  $colorBytes = substr($message,0,5);
  
  $backupMessage=$message;
  // find the first space or colon or semicolon
  $p=0;
  while (1) {
    if (substr( $message, 0, 1 ) === " " or substr($message,0,1)===":" or substr($message,0,1)===";") break ;
      $message = substr($message,1);
      # prevent never ending loop (It does seem to happen some how)
      if ( $p++ > 20 ) {
		  #something is wrong here. restore the message
		  $message = $backupMessage;
		  break;
		  }
      }

    $message = $colorBytes . substr($message,1);
    return $message;
}

// =================================================================================================================
function outputMessage($rowid){
	global $conn;
	global $lastprivate;
	global $regid;
	global $system_regid;
	global $timeoffset;
	global $previousPrivate;
	
	$private=true;
	$sql = "select * from messages where rowid='".$rowid."'";
	$result = $conn->query($sql);
	
	if ($row = $result->fetch_assoc()) {
		 
		$messageLine = trim($row["message"]);
		$messageLine = ltrim($messageLine);
		$messageLine = str_replace(str_repeat(" ", 40), "", $messageLine);
        $senders_regid=$row["regid"];
	    $localtime = $row["timestamp"];
	    
	    
	    // Get the offset of this server from UTC	    
	    date_default_timezone_set("GMT");	    	// this is UTC timezone
		$dateTimeGMT = date('Y-m-d H:i:s'); 
		
		date_default_timezone_set("CET");		    // this is the locals servers timezone   
		$dateTimeLocal = date('Y-m-d H:i:s');  		 
		    
		$date1 = strtotime($dateTimeGMT);
		$date2 = strtotime($dateTimeLocal);
		$diff = $date2 - $date1;					// diff is the offset in seconds
		
		
		date_default_timezone_set("CET"); 			// restore our timezone
		
		// calculate UTC time from the value in the database
		$timeoffset = str_replace(",", ".", $timeoffset);
		$timeoffset = floatval($timeoffset);
		$localtime = strtotime($row["timestamp"]) - $diff + ($timeoffset * 3600);
		$localtime =  date('Y-m-d H:i:s',$localtime);
		$channel='private';
		// system message
		if ($row["regid"] == $system_regid){  // this is a system message	
                        // calculate the age of the message
                        $rowTime = strtotime($row['timestamp']);
                        if ($rowTime < time() - 300) return;
			$channel='public';
			$message=trimMessage($messageLine);	
 	        	list($message,$len)=replace_higher_bytes($message);
			$message=invertText($message);	
		} elseif (($row["recipient"] ==  $regid) or ($row["regid"]==$regid and is_null($row["recipient"])==false )) {
			// private message
			$channel='private';
			$messageLine = cutAtName($messageLine);
			
			# remove point or comma from sendername
			$senderName= $row["sendername"];
			$senderName= str_replace(".", "", $senderName);
			$senderName= str_replace(",", "", $senderName);
			
			# remove point or comma from recipientname
			$recipName= $row["recipientname"];
			$recipName= str_replace(",", "", $recipName);
			$recipName= str_replace(".", "", $recipName);
			
			$senderRegId=$row["regid"];
			if (str_contains($messageLine, "^c^")){
				// Skip the header so the messages are stitched together
				$message=trimMessage($messageLine);
				$message=str_replace("^c^","",$message);
			}
			else {
				// create the header text for a private message:
				$message= $localtime . " " . $senderName . " @" . $recipName . ":";
				$message=invertText(str_pad($message,40)).$messageLine;
				$message=trimMessage($message);
				
			}
			
		} else {
			// public message
			$channel='public';
			// create the header text for a public message:
			$message= $localtime . " " . $row["sendername"] .":";
			$message=invertText(str_pad($message,40)).$messageLine;
			$message=trimMessage($message);
		}
		
		// get the message length and replace the higher bytes (that contain color information)
		// $message = ascii2Atari($message);
		list($message,$len)=replace_higher_bytes($message); 
	
		// calculate the number of lines.
		$len = ceil($len/40); 
		
		// build the json encoded string for output
		$message=base64_encode($message);
		
		// count the number of available private messages. We can not use $lastprivate for this because that will be zero at the start of every session
		// $previousPrivate is stored in eeprom so that contains the last private message id, even from the previous session.
		
		$pm=countPrivateMessages($regid,$previousPrivate); 
		
		$out=array('rowid' => $row["rowid"] , 'timestamp'=> $localtime, 'message' => $message, 'nickname'=>$row["sendername"] ,'lines'=>$len,'pm'=>$pm,'channel'=> $channel);
		 
 
		// output the row
		if (count($out) > 0 ) {
			echo json_encode($out);
		}
	}
	
}
// =================================================================================================================
function invertText($str)
{
	// This is only for Atari
	$nt = "";
	foreach (str_split($str) as $char) {
     $nt .= chr(128 + ord($char));
    }
    return $nt;
}

function ascii2Atari($str){
	$nt = "";
	foreach (str_split($str) as $char) {
	  if (ord($char) >= 97)  $nt .= $char;
	  else $nt .= chr(ord($char)-32);
    }
    return $nt;
	}
?>
