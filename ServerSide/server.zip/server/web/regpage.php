<?php
  require('registrationScript.php');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <title>Chat64</title>
	<style type="text/css">
	
	html{color:#FFF;background:#000;}
    
    @font-face { font-family: Kollektif; src: url('fonts/Kollektif-Bold.ttf'); } 
      
#page{
	font-family: Kollektif, monospace; 
	margin: auto;
	width: 1500px;	 
	position: relative;
	}
	
#header{
	text-align: center;
	position: relative;
	top:20px;
	}
	
#stripes{
	text-align: center;
	position: relative;
	background-image: url("img/p2.png");
	height: 70px;
	width: 1500px;
	top:20px;
	}
#homebutton{
	position: relative;
	
	background-image: url("img/homeb.jpg");
	height:44px;
	width:166px;
	top:-100px;
	}	
#homebutton:hover{
		background-image: url("img/homea.jpg") !important;
		cursor:pointer; 
	}
#table1,#table2,#table3{		
	width:100%;
	font-family: Kollektif, monospace; 
	font-size: 25px;
	color:#ff66c4;
	 
	}
	
#table1 tr td,#table2 tr td, #table3 tr td{vertical-align: top; text-align: left}
#table1 th,#table2 th, #table3 th {font-size: 40px; text-align: left}
#table1  tr td:nth-child(3),#table2 tr td:nth-child(3), #table3 tr td:nth-child(3) {
    text-align: right;  
}


.mylinks{
	border-bottom:4px solid black;	 
	}
.mylinks:hover{
	border-bottom:4px solid #ff66c4;	
	cursor:pointer; 
	}

#table1 tr td:nth-child(2) {
    text-align: center;  
}

#smdinfo, #thtinfo, #devinfo{
	font-size: 18px;
	display: none;
	border:0px solid white;	
	width: 1000px; 
	position:relative;
}
#smdinfo{
	left:0px;
	}

#thtinfo{
	left:0px;;
	}

#devinfo{
	left:0px;
	}

#menutable td {
	padding: 0px;
	line-height: 1px; 
	overflow:hidden;
	}


#m1:hover{
	content: url("img/m1a.jpg")
	}
#m2:hover{
	content: url("img/m2a.jpg")
	}
#m3:hover{
	content: url("img/m3a.jpg")
	}
#m4:hover{
	content: url("img/m4a.jpg")
	}
#m6:hover{
	content: url("img/m6a.jpg")
	}
#m7:hover{
	content: url("img/m7a.jpg")
	}
#m8:hover{
	content: url("img/m8a.jpg")
	}
#c64{
	position:relative;
	top:-160px;
	}
#gif1{
	position:relative;
	left:-160px;
	}

	.usertable1{
		position: relative;
        width:800px;
		font-family: Kollektif, monospace; 
		font-size: 30px;
		color: #cb6ce6;
		border-style: solid;
		border-color: #cb6ce6;;
		
	}
#menutable{
	position: relative;
	top:-25px;
	}	
	
	
.offline {color:white;}

.online {color:#7aad5c;}

 input[type=submit] {
	  position:relative;
	  background-image: url("img/fb1.jpg");
	  height:55px;
	  width:803px;
	  top:40px;
	  left:0px;
	  cursor:pointer; 
	  border: none;
	  font-size: 30px;
	  text-indent: -9999px;
	}
	
	input[type=submit]:hover{  
		  background-image: url("img/fb2.jpg") !important;
		  cursor:pointer;  
		  left:-6px;
	}
	
	.nameErr{
		position:relative;
		font-family: Kollektif, monospace; 
		font-size: 20px;
		color:#cb6ce6;
		top:-203px;
		left:220px;
		width:200px;
	}
	.emailErr{
		position:relative;
		font-family: Kollektif, monospace; 
		font-size: 20px;
		color:#cb6ce6;
		top:-195px;
		left:220px;
		width:200px;
	}
	.macErr{
		position:relative;
		font-family: Kollektif, monospace; 
		font-size: 20px;
		color:#cb6ce6;
		top:-190px;
		left:220px;
		width:200px;
	}	
	.register{
		position:relative;
		font-family: Kollektif, monospace; 
		font-size: 20px;
		color:#cb6ce6;
		top:100px;
		left:-120px;
		width:800px;
		}
	.form1{
		position: relative;
		display:inline-block;
		left:-200px;
		top:0px; 
		width:605px;
	}
</style>
<script>
   function onSubmit(token) {
     document.getElementById("regformv").submit();
   }
 </script>
</head>
  <body>
	<div id="page">
		<div id="header"><img src="img\p1.png" alt="chat64.nl" title="chat64"></div>
		<div id="stripes"></div>
		<div id="homebutton" onclick="location.href='index.html';"></div>		 
		<table id="table1">
			<tr>
				<td>
					<table id="menutable">
						<tr><td><a href="regpage.php"><img id="m1" src="img/m1.jpg" alt="register your cartridge"></a></td></tr>
						<tr><td><a href="about.php"><img id="m2" src="img/m2.jpg" alt="About page"></a></td></tr>
						<tr><td><a href="whoisonline.php"><img id="m3" src="img/m3.jpg" alt="See who is online"></a></td></tr>
						<tr><td height="100px;">&nbsp;</td></tr>
						<tr><td style="text-align:right;"><img src="img\p7.png" alt="chat cartridge"></td></tr>
					</table>
				</td><td> 
				<div  id="regform" class="form1" >
				<?php if ($register=='') {?>
				  <div style="padding-bottom:10px;"> <img src="img/f1.jpg" alt="form1"> </div>
				  <form id="regformv" action="" method="post" ">
					<div style="padding-top:30px;background-image: url('img/f2.jpg');background-repeat:no-repeat;height:20px; ">
					  <input style="position:relative;left:300px;top:-27px; width:350px; height:22px;"
						placeholder="Enter your full name!" name="full_name" value="<?php echo $set_fullName;?>" type="text">              
					</div>
					<div style="padding-top:0px;background-image: url('img/f3.jpg');background-repeat:no-repeat; height:44px; ">
					  <input style="position:relative;left:300px;top:0px; width:350px;  height:22px;"
						id="email" placeholder="Enter email" name="email" value="<?php echo $set_email;?>" type="text">
					</div>
					<div style="padding-top:0px;background-image: url('img/f4.jpg');background-repeat:no-repeat; height:44px; "><input style="position:relative;left:300px;top:5px; width:350px;  height:22px;"
						id="mac" placeholder="Enter mac address" name="mac" value="<?php echo $set_mac;?>" type="text"></div>
					  
					
                   <input type="submit">    
				   <?php } else {echo '<div id="register" class="register">'.$register.'</div>';}?>
				  </form>
				  <?php if($fnameErr!=1){ echo '<p class="nameErr">'.$fnameErr.'</p>'; } else { echo '<p class="nameErr">&nbsp;</p>'; } ?>
				  <?php if($emailErr!=1){ echo '<p class="emailErr">'.$emailErr.'</p>';} else { echo '<p class="emailErr">&nbsp;</p>'; } ?>
				  <?php if($macErr!=1){ echo '<p class="macErr">'.$macErr.'</p>'; } else { echo '<p class="macErr">&nbsp;</p>'; } ?>
				</div>
				</td>
			</tr>
		</table>
</body>
</html>
