<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once('../dbCredent.php');
$system_regid="666666cacacacaffff";
$halfOnPage=0;

//
// Bij omhoog scrollen.
// 1) We weten de top id niet, wel de bottom id.
// 2) zoek uit waar op het scherm die boodschap begint. Er kunnen immers systeem boodschappen tussendoor komen.
// 3) Geeft aan de php pagina wat het onderste id is en op welke regel die begint. De php pagina rekend uit wat de bovenste is.
//    als de bovenste maar half in beeld staat is dat de boodschap die je terug krijgt.
// 4) bij het weergeven. Kijk of regel nul een header is, zo niet, scroll omhoog tot regel nul een header is.
// 5) scroll naar beneden (het aantal regels in de boodschap)
// 6) geef de boodschap weer.
// 7) gooi de bottom id nu weg, die is niet meer betrouwbaar
// 8) bij verder omhoog scrollen is nu juist de top id bekend, dat maakt het eenvoudiger
// parameters voor de php pagina:
// a) top id (indien bekend, anders 0)
// b) bottom id (indien bekend, anders 0)
// wat krijg je terug
// a) nieuwe id, dat is het top id, verder zoals gebruikelijk
// b) aantal regels zoals gebruikelijk
// c) de boodschap zoals gebruikelijk

$system="Commodore" ;  // Commodore is the default
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  // POST should contain
  // regid, t (=timeoffset), bm (=botmes),tm (=topmes),lm (=lastMessageLine)
  
  if (isset($_POST["regid"])) $regid = test_input($_POST["regid"]);
  $timeoffset = "+1";
  if (isset($_POST["t"]))  $timeoffset =  test_input($_POST["t"]);
  if (isset($_POST["bm"])) $botmes = test_input($_POST["bm"]);
  if (isset($_POST["tm"])) $topmes = test_input($_POST["tm"]);
  if (isset($_POST["lm"])) $lastMessageline=test_input($_POST["lm"]);
  if (isset($_POST["p"])) $pagesize=test_input($_POST["p"]);
  if (isset($_POST["d"])) $direction=test_input($_POST["d"]); // 1 = up, 0 = down
  if (isset($_POST["system"])) $system = test_input($_POST["system"]);
  
} else {
$botmes=0 ;// regid=1111222233334444&bm=62897&tm=0&d=1&p=5&lm=21&t=+0
$topmes=0;//25554;  
$lastMessageline=21;  // the last message starts on line 20
$timeoffset=2; // the timeoffset of this user.
$regid='1010222288886666';
$pagesize=5; // 1 or 5
$direction=1; // 1 = up, 0 = down
$system="Commodore";
}



// Check connection
if ($conn->connect_error) {
  exit();
  die("Connection failed: " . $conn->connect_error);
}

if ($direction==1){ // scrolling UP
  if ($botmes==0) { // the bottom message might still be unknown (user did not wait for messages, straight into scrolling)
    $sql = "SELECT MAX(rowid) AS botmes FROM messages WHERE recipient IS NULL";
    $result = $conn->query($sql);

    if ($result && $row = $result->fetch_assoc()) {
        $botmes = $row['botmes'];
    }
  }
  if ($topmes==0){
    // find out what the top message is
    list($halfOnPage,$rowid)=getTopMessage_from_bottomMessage($botmes,$lastMessageline); 
  } else $rowid = getPreviousMessage($topmes);

  // output 5 messages (or just one)
  echo "[";
  outputMessage($rowid,$halfOnPage);

  for ($x=0;$x<($pagesize-1);$x++){
    echo ",";
    $rowid = getPreviousMessage($rowid);
    outputMessage($rowid,0);
  }
  echo "]";  
}
if ($direction==0){ // scrolling back down
  if ($botmes==0){
    // find the bottom message id, starting from the top message
    $rowid=getBottomMessage_from_topMessage($topmes);
    if ($pagesize==1) $pagesize++;
  } else $rowid = getNextMessage($botmes);
  if ($rowid == $botmes) exit();
  // output 5 messages (or just one)
  echo "[";
  outputMessage($rowid,$halfOnPage);
  $lastid = $rowid;
  for ($x=0;$x<($pagesize-1);$x++){
    echo ",";
    $rowid = getNextMessage($rowid);
    if ($lastid != $rowid)  outputMessage($rowid,0);
    $lastid = $rowid;
  }
  echo "]";  
}
// =================================================================================================================
function getBottomMessage_from_topMessage($topmes){
  // if you only know the top message, this can calculate the bottom message.
  // it always returns the bottom message that should still be (partly) visible on screen
  global $conn;	
  global $system_regid; 
  // select 11 messages that are all < than $botmes
  $sql = "select * from messages where recipient is null and regid not in ('".$system_regid."','') and rowid > ". $topmes . " order by rowid asc Limit 11";
  $result = $conn->query($sql);
  $screensize=20;
  $botrow=0;
  // now we calculate what message is on top of the screen
  while ($row = $result->fetch_assoc()) {   
    $len = getMessageSize($row["rowid"]); // this returns the number of lines
    $screensize = $screensize - $len;
    if ($screensize <= 1) {
      $botrow=$row["rowid"];
      break; 
    }
  }
  return $botrow;
}
// =================================================================================================================
function getNextMessage($mesid){
  // this returns the message id for the message after $mesid
  global $conn;	
  global $system_regid;
  $sql = "select rowid from messages where recipient is null and regid not in ('".$system_regid."','') and rowid > ". $mesid . " order by rowid asc Limit 1";
  $result = $conn->query($sql);
  if ($row = $result->fetch_assoc()) { 
    return $row["rowid"];
  }
  return $mesid;
}
// =================================================================================================================
function getPreviousMessage($mesid){
  // this returns the message id for the message before $mesid
  global $conn;	
  global $system_regid;
  $sql = "select rowid from messages where recipient is null and regid not in ('".$system_regid."','') and rowid < ". $mesid . " order by rowid desc Limit 1";
  $result = $conn->query($sql);
  if ($row = $result->fetch_assoc()) { 
    return $row["rowid"];
  }
  return $mesid;
}
// =================================================================================================================
function getTopMessage_from_bottomMessage($botmes,$lastMessageline){
  // if you only know the bottom message, this can calculate the top message.
  // it also returns a "1" if the topmessage is only half visible on the page.
  global $conn;	
  global $system_regid;  
  // select 11 messages that are all < than $botmes
  $sql = "select * from messages where recipient is null and regid not in ('".$system_regid."','') and rowid < ". $botmes . " order by rowid desc Limit 11";
  $result = $conn->query($sql);
  $screensize=$lastMessageline ; // on the commodore screen there are 21 message lines max
  $toprow=0;
  $halfOnPage=1;
  // now we calculate what message is on top of the screen
  while ($row = $result->fetch_assoc()) {   
    $len = getMessageSize($row["rowid"]); // this returns the number of lines
    $screensize = $screensize - $len;
    if ($screensize <= 1) {
      $toprow=$row["rowid"];
      break; 
    }
  }
  if ($screensize==1) $halfOnPage=0;
  return array($halfOnPage,$toprow);
}
// =================================================================================================================
function getMessageSize($rowid){
    // this returns the number of lines that a message takes up on the screen.
  	global $conn;	
	global $system_regid;
    $sql="select message from messages where rowid=".$rowid;
    $result = $conn->query($sql);
    if ($row = $result->fetch_assoc()) {
      $message=$row["message"];
      $message=str_replace(str_repeat(" ", 40),"",$message);
      $message=str_replace(str_repeat(" ", 32),"",$message);
      list($message,$len)=replace_higher_bytes($message);  
      // calculate the number of lines.
	  $len = ceil($len/40); 
      $len++; // add one line for the header
      return $len;
    }
    return 0;
}
// =================================================================================================================
function replace_higher_bytes($str){
  global $system;
  
  // use the atari version of this function for Atari
  if ($system=='Atari') return replace_higher_bytes_atari($str);
  if ($system=='MSX') return replace_higher_bytes_atari($str);
  
  
  // this function replaces the [145] for byte value 145 and returns also the length of the message excluding those bytes.
  $pattern = "/\[\d\d\d\]/";
  preg_match_all($pattern, $str,$out);
    $c=0;
    foreach ($out[0] as $o) {
      $v=intval(substr($o,1,-1));
      $str = str_replace($o,chr($v),$str);
      $c++;
    }
  return array($str,strlen($str)-$c);
}

function replace_higher_bytes_atari($str){
  // this function replaces the [145] for ''.
  $pattern = "/\[\d\d\d\]/";
  preg_match_all($pattern, $str,$out);
    foreach ($out[0] as $o) {      
      $str = str_replace($o,'',$str);
    }
  $str=str_replace(str_repeat(" ",40),"",$str);  
  $str=str_replace(str_repeat(" ",32),"",$str);  
  return array($str,strlen($str));
}


// =================================================================================================================
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
// =================================================================================================================
function trimMessage($message){
  $message=trim($message);

  // sometimes, for some reason, there are extra bytes at the end of the message.
  // They are formatted like this [nnn]. We need to delete those.
  
  while (preg_match("/^\[\d\d\d\]$/",substr($message,-5))) {
      $message=substr($message,0,-5);
      $message=trim($message);      
  }
  return $message;
}
// =================================================================================================================
function cutAtName($message){
  // save the color byte for later
  if (substr($message,0,1)==="[" )  $colorBytes = substr($message,0,5);
  
  $backupMessage=$message;
  // find the first space or colon or semicolon
  $p=0;
  while (1) {
    if (substr( $message, 0, 1 ) === " " or substr($message,0,1)===":" or substr($message,0,1)===";") break ;
      $message = substr($message,1);
      # prevent never ending loop (It does seem to happen some how)
      if ( $p++ > 20 ) {
		  #something is wrong here. restore the message
		  $message = $backupMessage;
		  break;
		  }
      }

    $message = $colorBytes . substr($message,1);
    return $message;
}

// =================================================================================================================
function outputMessage($rowid,$halfOnPage){
	global $conn;
	global $lastprivate;
	global $regid;
	global $system_regid;
	global $timeoffset;
	global $previousPrivate;
    global $system;
	
	$private=true;
	$sql = "select * from messages where rowid='".$rowid."'";
	 
	$result = $conn->query($sql);
	
	if ($row = $result->fetch_assoc()) {
		 
		$messageLine = trim($row["message"]);
		$messageLine = ltrim($messageLine);
		$messageLine = str_replace(str_repeat(" ",40), "", $messageLine);
        $messageLine = str_replace(str_repeat(" ",32), "", $messageLine);
        $senders_regid=$row["regid"];
	    $localtime = $row["timestamp"];
	    
	    
	    // Get the offset of this server from UTC	    
	    date_default_timezone_set("GMT");	    	// this is UTC timezone
		$dateTimeGMT = date('Y-m-d H:i:s'); 
		
		date_default_timezone_set("CET");		    // this is the locals servers timezone   
		$dateTimeLocal = date('Y-m-d H:i:s');  		 
		    
		$date1 = strtotime($dateTimeGMT);
		$date2 = strtotime($dateTimeLocal);
		$diff = $date2 - $date1;					// diff is the offset in seconds
		
		
		date_default_timezone_set("CET"); 			// restore our timezone
		
		// calculate UTC time from the value in the database
		$timeoffset = str_replace(",", ".", $timeoffset);
		$timeoffset = floatval($timeoffset);
		$localtime = strtotime($row["timestamp"]) - $diff + ($timeoffset * 3600);
		
        if ($system=="ZX") $localtime =  date('y-m-d H:i',$localtime);
        else $localtime =  date('Y-m-d H:i:s',$localtime);
        
		$channel='scroll';
		// system message
		if ($row["regid"] == $system_regid){
			// this is a system message	
			
			$channel='scroll';
			$message=trimMessage($messageLine); 	
			
		} elseif (($row["recipient"] ==  $regid) or ($row["regid"]==$regid and is_null($row["recipient"])==false )) {
			// private message
			$channel='scroll';
			$messageLine = cutAtName($messageLine);
			
			# remove point or comma from servername
			$senderName= $row["sendername"];
			$senderName= str_replace(".", "", $senderName);
			$senderName= str_replace(",", "", $senderName);
			
			# remove point or comma from recipientname
			$recipName= $row["recipientname"];
			$recipName= str_replace(",", "", $recipName);
			$recipName= str_replace(".", "", $recipName);
			
			$senderRegId=$row["regid"];
			if (str_contains($messageLine, "^c^")){
				// Skip the header so the messages are stitched together
				$message=trimMessage($messageLine);
				$message=str_replace("^c^","",$message);
			}
			else {
				// create the header text for a private message:
				$message="[151]" . $localtime . " " . $senderName . " @" . $recipName . ":";
				$message=str_pad($message,45).$messageLine;
				$message=trimMessage($message);
			}
			
		} else {
			// public message
			$channel='scroll';
			// create the header text for a public message:
            $pad = 45;
            if ($system=="ZX") $pad=37;
			$message="[151]". $localtime . " " . $row["sendername"] .":";
			$message=str_pad($message,$pad).$messageLine;
			$message=trimMessage($message);
		}
		
		// get the message length and replace the higher bytes (that contain color information)
		list($message,$len)=replace_higher_bytes($message); 
	
		// calculate the number of lines.		 
        if ($system=="ZX") $len = ceil($len/32); 
        else $len = ceil($len/40);
        
		// build the json encoded string for output
		$message=base64_encode($message);
		
		// count the number of available private messages. We can not use $lastprivate for this because that will be zero at the start of every session
		// $previousPrivate is stored in eeprom so that contains the last private message id, even from the previous session.
		
		$pm=0; //countPrivateMessages($regid,$previousPrivate); 
		
		$out=array('rowid' => $row["rowid"] , 'message' => $message, 'lines'=>$len,'hp'=>$halfOnPage, 'channel'=> $channel);
		 
		// output the row
		if (count($out) > 0 ) {
			echo json_encode($out);			 
		}
	}
	
}

?>
