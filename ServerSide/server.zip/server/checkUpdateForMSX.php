<?php
echo (file_get_contents('./update/msxversion.txt'));
?>
